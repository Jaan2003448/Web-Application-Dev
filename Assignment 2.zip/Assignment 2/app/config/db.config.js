module.exports = {
    //url: "mongodb://localhost:27017/DressStore"
    url: "mongodb+srv://jaanpatel2004:assignment_2@dressstore.73a6kvs.mongodb.net/DressStore?retryWrites=true&w=majority"
    };