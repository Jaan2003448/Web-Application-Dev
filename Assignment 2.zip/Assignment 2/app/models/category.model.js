module.exports = mongoose => {

    const Categories = mongoose.model(
  
      "categories",
  
      mongoose.Schema(
  
        {
              category:String
        },
  
       
  
      )
  
    );
  
   
  
    return Categories;
  
  };