module.exports = mongoose => {

    const Products = mongoose.model(
  
      "products",
  
      mongoose.Schema(
  
        {
  
              name: String,
  
              description: String,
  
              price:Number,

              published:Boolean,
  
              category:String
  
        },
  
       
  
      )
  
    );
  
   
  
    return Products;
  
  };